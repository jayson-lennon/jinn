//! The client region registry — the TypeScript half of the server's
//! `region.rs` registry.
//!
//! One module per region, mirroring the Rust side one-for-one:
//! sessions, transcript, composer, model_picker. A region module
//! registers its delegation selectors (contract-derived), its event
//! handlers, and its SSE event handlers. `main.ts` consumes the
//! registry generically — the boot module names no region.
//!
//! ## Ownership contract (the `SliceView` discipline, client-side)
//!
//! Every region module is a pure renderer of what the server pushed:
//!
//! - It owns **no application state** — the server is authoritative,
//!   and the DOM plus the URL are the client's only memory. The only
//!   permitted module-level binding is the registry entry itself.
//! - It owns only **view-local DOM state** (e.g. an optimistic entry
//!   the next server push reconciles).
//! - It reads the viewed session id fresh from the page's data
//!   attribute at handler time — a page swap can change it under any
//!   closure, so nothing may cache it.
//!
//! A module that reaches for a shared state store is violating this
//! contract, not extending it.
//!
//! ## Disjointness requirement
//!
//! The delegation selectors across region modules MUST be pairwise
//! disjoint — the registry's dispatch is first-match, and an overlap
//! would silently change which region handles an event. The jsdom
//! conformance test asserts this; it is what licenses the simple
//! dispatch loop.
import { sessionsRegion } from "./sessions.1808d7f4.js";
import { transcriptRegion } from "./transcript.5ce0f0ee.js";
import { composerRegion } from "./composer.53e444f0.js";
import { modelPickerRegion } from "./model_picker.ae9faf64.js";
/** The registered regions, in registration order (mirrors the server). */
const REGIONS = [
    sessionsRegion,
    transcriptRegion,
    composerRegion,
    modelPickerRegion,
];
/** The registered regions, in registration order. */
export function regions() {
    return REGIONS;
}
/** The SSE event names across all regions' handlers. */
export function sseEventNames() {
    return REGIONS.flatMap((region) => Object.keys(region.sseHandlers));
}
